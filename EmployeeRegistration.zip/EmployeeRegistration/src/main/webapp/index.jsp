<%@ page contentType="text/html;charset=UTF-8" %>
<html>
<head>
    <title>Employee Management</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; margin-top: 100px; background: #f0f2f5; }
        .btn { padding: 12px 28px; margin: 10px; font-size: 16px;
               border: none; border-radius: 6px; cursor: pointer; text-decoration: none; }
        .btn-primary { background: #4CAF50; color: white; }
        .btn-secondary { background: #2196F3; color: white; }
    </style>
</head>
<body>
    <h1>Employee Registration System</h1>
    <p>Manage your employee records efficiently</p>
    <a href="employee?action=register" class="btn btn-primary">Register Employee</a>
    <a href="employee?action=list"     class="btn btn-secondary">View All Employees</a>
</body>
</html>
