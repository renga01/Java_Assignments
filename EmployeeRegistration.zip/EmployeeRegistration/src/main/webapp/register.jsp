<%@ page contentType="text/html;charset=UTF-8" %>
<html>
<head>
    <title>Register Employee</title>
    <style>
        body       { font-family: Arial, sans-serif; background: #f0f2f5; }
        .container { max-width: 600px; margin: 40px auto; background: white;
                     padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        h2         { text-align: center; color: #333; }
        .form-group { margin-bottom: 18px; }
        label      { display: block; margin-bottom: 6px; font-weight: bold; color: #555; }
        input, select { width: 100%; padding: 10px; border: 1px solid #ddd;
                        border-radius: 5px; box-sizing: border-box; font-size: 14px; }
        .btn-submit { width: 100%; padding: 12px; background: #4CAF50; color: white;
                      border: none; border-radius: 5px; font-size: 16px; cursor: pointer; }
        .btn-submit:hover { background: #45a049; }
        .error     { color: red; background: #ffe0e0; padding: 10px;
                     border-radius: 5px; margin-bottom: 15px; }
        .back-link { display: block; text-align: center; margin-top: 15px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Register New Employee</h2>

    <% String error = (String) request.getAttribute("error");
       if (error != null) { %>
        <div class="error"><%= error %></div>
    <% } %>

    <form action="employee" method="post">
        <div class="form-group">
            <label>First Name *</label>
            <input type="text" name="firstName" required placeholder="Enter first name"/>
        </div>
        <div class="form-group">
            <label>Last Name *</label>
            <input type="text" name="lastName" required placeholder="Enter last name"/>
        </div>
        <div class="form-group">
            <label>Email *</label>
            <input type="email" name="email" required placeholder="Enter email"/>
        </div>
        <div class="form-group">
            <label>Phone</label>
            <input type="tel" name="phone" placeholder="Enter phone number"/>
        </div>
        <div class="form-group">
            <label>Department</label>
            <select name="department">
                <option value="">-- Select Department --</option>
                <option>Engineering</option>
                <option>Human Resources</option>
                <option>Finance</option>
                <option>Marketing</option>
                <option>Operations</option>
                <option>Sales</option>
            </select>
        </div>
        <div class="form-group">
            <label>Designation</label>
            <input type="text" name="designation" placeholder="e.g. Software Engineer"/>
        </div>
        <div class="form-group">
            <label>Salary</label>
            <input type="number" name="salary" step="0.01" placeholder="Enter salary"/>
        </div>
        <div class="form-group">
            <label>Join Date</label>
            <input type="date" name="joinDate"/>
        </div>
        <button type="submit" class="btn-submit">Register Employee</button>
    </form>
    <a class="back-link" href="index.jsp">← Back to Home</a>
</div>
</body>
</html>
