<%@ page contentType="text/html;charset=UTF-8" %>
<html>
<head>
    <title>Registration Successful</title>
    <style>
        body       { font-family: Arial, sans-serif; background: #f0f2f5; text-align: center; margin-top: 100px; }
        .card      { display: inline-block; background: white; padding: 40px 60px;
                     border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .checkmark { font-size: 64px; }
        h2         { color: #4CAF50; }
        .btn       { padding: 10px 25px; margin: 8px; border: none; border-radius: 5px;
                     cursor: pointer; font-size: 14px; text-decoration: none; }
        .btn-green { background: #4CAF50; color: white; }
        .btn-blue  { background: #2196F3; color: white; }
    </style>
</head>
<body>
<div class="card">
    <div class="checkmark">✅</div>
    <h2>Registration Successful!</h2>
    <p>${message}</p>
    <a href="employee?action=register" class="btn btn-green">Register Another</a>
    <a href="employee?action=list"     class="btn btn-blue">View All Employees</a>
</div>
</body>
</html>
