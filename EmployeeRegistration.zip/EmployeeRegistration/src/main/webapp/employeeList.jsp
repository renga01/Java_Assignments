<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib uri="jakarta.tags.core" prefix="c" %>
<html>
<head>
    <title>Employee List</title>
    <style>
        body       { font-family: Arial, sans-serif; background: #f0f2f5; padding: 20px; }
        h2         { text-align: center; color: #333; }
        .top-bar   { text-align: right; margin-bottom: 15px; }
        .btn       { padding: 9px 20px; border: none; border-radius: 5px;
                     cursor: pointer; font-size: 14px; text-decoration: none; }
        .btn-green  { background: #4CAF50; color: white; }
        .btn-red    { background: #f44336; color: white; }
        table      { width: 100%; border-collapse: collapse; background: white;
                     border-radius: 10px; overflow: hidden;
                     box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        th         { background: #4CAF50; color: white; padding: 12px 15px; text-align: left; }
        td         { padding: 11px 15px; border-bottom: 1px solid #eee; }
        tr:hover td { background: #f9f9f9; }
        .no-data   { text-align: center; padding: 30px; color: #999; }
        .badge     { padding: 4px 10px; border-radius: 12px; font-size: 12px;
                     background: #e3f2fd; color: #1565c0; }
    </style>
</head>
<body>
    <h2>Employee Records</h2>

    <div class="top-bar">
        <a href="employee?action=register" class="btn btn-green">+ Register New Employee</a>
    </div>

    <table>
        <thead>
            <tr>
                <th>#</th>
                <th>Name</th>
                <th>Email</th>
                <th>Phone</th>
                <th>Department</th>
                <th>Designation</th>
                <th>Salary</th>
                <th>Join Date</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <c:choose>
                <c:when test="${empty employees}">
                    <tr><td colspan="9" class="no-data">No employees registered yet.</td></tr>
                </c:when>
                <c:otherwise>
                    <c:forEach var="emp" items="${employees}" varStatus="s">
                        <tr>
                            <td>${s.count}</td>
                            <td>${emp.firstName} ${emp.lastName}</td>
                            <td>${emp.email}</td>
                            <td>${emp.phone}</td>
                            <td><span class="badge">${emp.department}</span></td>
                            <td>${emp.designation}</td>
                            <td>&#8377;${emp.salary}</td>
                            <td>${emp.joinDate}</td>
                            <td>
                                <a href="employee?action=delete&id=${emp.id}"
                                   class="btn btn-red"
                                   onclick="return confirm('Delete this employee?')">Delete</a>
                            </td>
                        </tr>
                    </c:forEach>
                </c:otherwise>
            </c:choose>
        </tbody>
    </table>
</body>
</html>
