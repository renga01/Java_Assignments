package com.employee.model;

import java.math.BigDecimal;
import java.sql.Date;

public class Employee {
    private int id;
    private String firstName;
    private String lastName;
    private String email;
    private String phone;
    private String department;
    private String designation;
    private BigDecimal salary;
    private Date joinDate;

    public Employee() {}

    public Employee(int id, String firstName, String lastName, String email,
                    String phone, String department, String designation,
                    BigDecimal salary, Date joinDate) {
        this.id = id; this.firstName = firstName; this.lastName = lastName;
        this.email = email; this.phone = phone; this.department = department;
        this.designation = designation; this.salary = salary; this.joinDate = joinDate;
    }

    public int getId()                        { return id; }
    public void setId(int id)                 { this.id = id; }
    public String getFirstName()              { return firstName; }
    public void setFirstName(String f)        { this.firstName = f; }
    public String getLastName()               { return lastName; }
    public void setLastName(String l)         { this.lastName = l; }
    public String getEmail()                  { return email; }
    public void setEmail(String email)        { this.email = email; }
    public String getPhone()                  { return phone; }
    public void setPhone(String phone)        { this.phone = phone; }
    public String getDepartment()             { return department; }
    public void setDepartment(String dept)    { this.department = dept; }
    public String getDesignation()            { return designation; }
    public void setDesignation(String desig)  { this.designation = desig; }
    public BigDecimal getSalary()             { return salary; }
    public void setSalary(BigDecimal salary)  { this.salary = salary; }
    public Date getJoinDate()                 { return joinDate; }
    public void setJoinDate(Date joinDate)    { this.joinDate = joinDate; }
}
