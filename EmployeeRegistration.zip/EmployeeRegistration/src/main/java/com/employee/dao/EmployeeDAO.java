package com.employee.dao;

import com.employee.model.Employee;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class EmployeeDAO {

    public boolean registerEmployee(Employee emp) throws SQLException {
        String sql = "INSERT INTO employees (first_name, last_name, email, phone, " +
                     "department, designation, salary, join_date) VALUES (?,?,?,?,?,?,?,?)";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, emp.getFirstName()); ps.setString(2, emp.getLastName());
            ps.setString(3, emp.getEmail());     ps.setString(4, emp.getPhone());
            ps.setString(5, emp.getDepartment()); ps.setString(6, emp.getDesignation());
            ps.setBigDecimal(7, emp.getSalary()); ps.setDate(8, emp.getJoinDate());
            return ps.executeUpdate() > 0;
        }
    }

    public List<Employee> getAllEmployees() throws SQLException {
        List<Employee> list = new ArrayList<>();
        String sql = "SELECT * FROM employees ORDER BY created_at DESC";
        try (Connection con = DBConnection.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                list.add(new Employee(rs.getInt("id"), rs.getString("first_name"),
                    rs.getString("last_name"), rs.getString("email"), rs.getString("phone"),
                    rs.getString("department"), rs.getString("designation"),
                    rs.getBigDecimal("salary"), rs.getDate("join_date")));
            }
        }
        return list;
    }

    public Employee getEmployeeById(int id) throws SQLException {
        String sql = "SELECT * FROM employees WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return new Employee(rs.getInt("id"), rs.getString("first_name"),
                        rs.getString("last_name"), rs.getString("email"), rs.getString("phone"),
                        rs.getString("department"), rs.getString("designation"),
                        rs.getBigDecimal("salary"), rs.getDate("join_date"));
                }
            }
        }
        return null;
    }

    public boolean deleteEmployee(int id) throws SQLException {
        String sql = "DELETE FROM employees WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        }
    }
}
