package com.employee.servlet;

import com.employee.dao.EmployeeDAO;
import com.employee.model.Employee;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;

import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Date;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/employee")
public class EmployeeServlet extends HttpServlet {

    private final EmployeeDAO dao = new EmployeeDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        String action = req.getParameter("action");
        if (action == null) action = "list";

        try {
            switch (action) {
                case "register" ->
                    req.getRequestDispatcher("/register.jsp").forward(req, res);
                case "delete" -> {
                    int id = Integer.parseInt(req.getParameter("id"));
                    dao.deleteEmployee(id);
                    res.sendRedirect("employee?action=list");
                }
                default -> {
                    List<Employee> employees = dao.getAllEmployees();
                    req.setAttribute("employees", employees);
                    req.getRequestDispatcher("/employeeList.jsp").forward(req, res);
                }
            }
        } catch (SQLException e) {
            throw new ServletException("Database error", e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse res)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        try {
            Employee emp = new Employee();
            emp.setFirstName(req.getParameter("firstName"));
            emp.setLastName(req.getParameter("lastName"));
            emp.setEmail(req.getParameter("email"));
            emp.setPhone(req.getParameter("phone"));
            emp.setDepartment(req.getParameter("department"));
            emp.setDesignation(req.getParameter("designation"));
            emp.setSalary(new BigDecimal(req.getParameter("salary")));
            emp.setJoinDate(Date.valueOf(req.getParameter("joinDate")));

            boolean success = dao.registerEmployee(emp);
            if (success) {
                req.setAttribute("message", "Employee registered successfully!");
                req.getRequestDispatcher("/success.jsp").forward(req, res);
            } else {
                req.setAttribute("error", "Registration failed. Please try again.");
                req.getRequestDispatcher("/register.jsp").forward(req, res);
            }
        } catch (SQLException e) {
            req.setAttribute("error", "Database error: " + e.getMessage());
            req.getRequestDispatcher("/register.jsp").forward(req, res);
        }
    }
}
